# Environments

This is a simple docker-compose.yml for testing purposes. There are two services running in separate containers:

- `web` contains a Debian 12 image running Apache
- `db` contains a running MySQL (MariaDB) server listening on port 3306, with password `admin`

# Instructions

First, clone this repo with

```
$ git clone https://gitlab.tmobil.com.br/turismo/environments
$ cd environments
```

You can launch the two services with the following command (you might need admin privileges):

```
$ docker compose up
```

You can test if Apache is running by accessing `http://localhost:80`.

To get a shell within the `web` container running Apache, run

```
$ docker compose exec web bash
```
